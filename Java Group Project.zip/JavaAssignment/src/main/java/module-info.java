module com.example.javaassignment {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;
    requires java.desktop;
    requires jbcrypt;


    opens com.example.javaassignment to javafx.fxml;
    exports com.example.javaassignment;
}