package com.example.javaassignment;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.mindrot.jbcrypt.BCrypt;

public class AdminProfile {
    @FXML
    public TextArea admnFacultyField;
    @FXML
    private AnchorPane AdminAnchorPaneWithShowProfileBtn;
    @FXML
    private Pane AdminInfoPane;
    @FXML
    private TableColumn<Module, String> moduleNameColumnView;
    @FXML
    private TableColumn<Module, String> moduleCodeColumnView;
    @FXML
    private TableColumn<Module, String> moduleAcademicYearViewColumn;
    @FXML
    private TableColumn<Module, Void> moduleActionColumn; // Action column for delete button
    @FXML
    private ComboBox<ComboBoxItem> academicYearDropdown;
    @FXML
    private TableColumn<Semester, String> academicYearSemesterColumn;
    @FXML
    private ComboBox<ComboBoxItem> academicYearSemesterDropdown;
    @FXML
    private TableColumn<Semester, Void> actionBtnColumnSemester;
    @FXML
    private AnchorPane adminDetailsAnchorPane;
    @FXML
    private TextArea admnEmailField;
    @FXML
    private TextArea admnFacaltyField;
    @FXML
    private TextArea admnIDField;
    @FXML
    private TextArea admnNameField;
    @FXML
    private AnchorPane anchorPaneAddClass;
    @FXML
    private AnchorPane anchorPaneAddLecture;
    @FXML
    private AnchorPane anchorPaneAddModule;
    @FXML
    private AnchorPane anchorPaneAddStudent;
    @FXML
    private AnchorPane anchorPaneAddYearSemester;
    @FXML
    private AnchorPane anchorPaneAdminDashboard;
    @FXML
    private AnchorPane anchorPaneViewLecturers;
    @FXML
    private AnchorPane anchorPaneViewModules;
    @FXML
    private AnchorPane anchorPaneViewSemesters;
    @FXML
    private AnchorPane anchorPaneManageLecturer;
    @FXML
    private ComboBox<?> assignModuleDropdown;
    @FXML
    private ComboBox<?> assignRoleDropdown;
    @FXML
    private ComboBox<ComboBoxItem> assignStudentsClassDropdown;
    @FXML
    private Button btnAddAcademicYear;
    @FXML
    private Button btnAddAccademicYearAndSemester;
    @FXML
    private Button btnAddAndManageLecturers;
    @FXML
    private Button btnAddAndManageStudents;
    @FXML
    private Button btnAddClass;
    @FXML
    private Button btnAddLecture;
    @FXML
    private Button btnAddModule;
    @FXML
    private Button btnAddSemester;
    @FXML
    private Button btnAddStudent;
    @FXML
    private Button btnClearAcademicYearFields;
    @FXML
    private Button btnClearClassFields;
    @FXML
    private Button btnClearLectureFields;
    @FXML
    private Button btnClearModuleFields;
    @FXML
    private Button btnClearSemesterFields;
    @FXML
    private Button btnClearStudentFields;
    @FXML
    private Button btnHideAdInfo;
    @FXML
    private Button btnHome1;
    @FXML
    private Button btnHome2;
    @FXML
    private Button btnHome3;
    @FXML
    private Button btnHome4;
    @FXML
    private Button btnHome5;
    @FXML
    private Button btnHome51;
    @FXML
    private Button btnHome511;
    @FXML
    private Button btnHome5111;
    @FXML
    private Button btnLogout;
    @FXML
    private Button btnShowAdInfo;
    @FXML
    private Button btnSubmitAddClass;
    @FXML
    private Button btnSubmitModule;
    @FXML
    private Button btnViewLectures;
    @FXML
    private Button btnViewModules;
    @FXML
    private Button btnViewSemester;
    @FXML
    private ComboBox<ComboBoxItem> chooseAcademicYearDropdown;
    @FXML
    private ComboBox<ComboBoxItem> chooseClassDropdown;
    @FXML
    private ComboBox<ComboBoxItem> chooseSemesterDropdown;
    @FXML
    private ComboBox<ComboBoxItem> semesterDropdown;
    @FXML
    private TableColumn<Semester, LocalDate> endDateViewSemesterColumn;
    @FXML
    private DatePicker fieldAcademicEndDate;
    @FXML
    private DatePicker fieldAcademicStartDate;
    @FXML
    private TextField fieldClassCode;
    @FXML
    private TextField fieldClassName;
    @FXML
    private TextField fieldLectureID;
    @FXML
    private TextField fieldLectureName;
    @FXML
    private TextField fieldModuleCode;
    @FXML
    private TextField fieldModuleName;
    @FXML
    private DatePicker fieldSemesterEndDate;
    @FXML
    private TextField fieldSemesterName;
    @FXML
    private DatePicker fieldSemesterStartDate;
    @FXML
    private TextField fieldStudentID;
    @FXML
    private TextField fieldStudentName;
    @FXML
    private Label lblAdminEmail;
    @FXML
    private Label lblAdminFaculty;
    @FXML
    private Label lblAdminID;
    @FXML
    private Label lblAdminID1;
    @FXML
    private Text lblAdminName;
    @FXML
    private Text lblNumOfLectures;
    @FXML
    private Text lblNumOfStudentsEnrolled;
    @FXML
    private TableColumn<Lecturer, String> lectureViewIdColumn; // Change to hold String for ID
    @FXML
    private TableColumn<Lecturer, String> lectureViewNameColumn; // Change to hold String for Name
    @FXML
    private TableColumn<Lecturer, String> lectureViewRoleColumn; // Change to hold String for Role
    @FXML
    private TableColumn<Lecturer, Void> lectureViewActionColumn;
    @FXML
    private NumberAxis studentCountAxis;
    @FXML
    private TableColumn<Semester, String> semesterNameColumnView;
    @FXML
    private TableColumn<Semester, LocalDate> startDateViewSemesterColumn;
    @FXML
    private CategoryAxis classAxis;
    @FXML
    private BarChart<String, Number> studentsChart;
    @FXML
    private TableView<Lecturer> viewLecturesTable;
    @FXML
    private TableView<Module> viewModulesTable;
    @FXML
    private TableView<Semester> viewModulesTable1;
    @FXML
    private ComboBox<ComboBoxItem> ChooseModuleDropdownML;
    @FXML
    private Button btnClearLectureFieldsML;
    @FXML
    private Button btnHomeML;
    @FXML
    private ComboBox<ComboBoxItem> chooseAcademicYearML;
    @FXML
    private ComboBox<ComboBoxItem> chooseClassDropdownML;
    @FXML
    private ComboBox<ComboBoxItem> chooseLecturerDropdownML;
    @FXML
    private ComboBox<ComboBoxItem> chooseSemesterDropdownML;
    @FXML
    private Button btnBackML;

    @FXML
    public void initialize() {
        loadAdminInfo(); // Load admin info when the view is initialized
        loadComboBoxData(); // Load all ComboBox data
        loadStudentCount(); // Load the number of students
        loadLecturerCount(); // Load the number of lecturers
        loadStudentCountsPerClass(); // Load student counts per class for the chart

        // Set up the table columns
        lectureViewIdColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getId()));
        lectureViewNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        lectureViewRoleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getRole()));

        // Set up the action column with delete buttons
        lectureViewActionColumn.setCellFactory(col -> new TableCell<Lecturer, Void>() {
            private final Button deleteButton = new Button("Delete");

            {
                deleteButton.setOnAction(event -> {
                    Lecturer lecturer = getTableView().getItems().get(getIndex());
                    deleteLecturer(lecturer);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(deleteButton);
                }
            }
        });

        // Set up the table columns for modules
        moduleNameColumnView.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        moduleCodeColumnView.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCode()));
        moduleAcademicYearViewColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAcademicYear())); // Display academic year as a string

        // Set up the action column with delete buttons
        moduleActionColumn.setCellFactory(col -> new TableCell<Module, Void>() {
            private final Button deleteButton = new Button("Delete");

            {
                deleteButton.setOnAction(event -> {
                    Module module = getTableView().getItems().get(getIndex());
                    deleteModule(module.getCode()); // Use the module code to delete
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(deleteButton);
                }
            }
        });

        // Set up the table columns for semesters
        semesterNameColumnView.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        startDateViewSemesterColumn.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().getStartDate()));
        endDateViewSemesterColumn.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().getEndDate()));
        academicYearSemesterColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAcademicYear()));

        // Load semesters into the table when the view is initialized
        loadSemestersIntoTable();

        // Set up the action column with delete buttons for semesters
        actionBtnColumnSemester.setCellFactory(col -> new TableCell<Semester, Void>() {
            private final Button deleteButton = new Button("Delete");

            {
                deleteButton.setOnAction(event -> {
                    Semester semester = getTableView().getItems().get(getIndex());
                    deleteSemester(semester); // Call the method to delete the semester
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(deleteButton);
                }
            }
        });
    }

    private void deleteSemester(Semester semester) {
        String query = "DELETE FROM Semester WHERE name = ? AND start_date = ? AND end_date = ?"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, semester.getName());
            preparedStatement.setDate(2, java.sql.Date.valueOf(semester.getStartDate()));
            preparedStatement.setDate(3, java.sql.Date.valueOf(semester.getEndDate()));

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Semester deleted successfully.");
                loadSemestersIntoTable(); // Refresh the table after deletion
            } else {
                showAlert("Error", "Failed to delete semester.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while deleting the semester.");
        }
    }

    public class Module {
        private int id;
        private String name;
        private String code;
        private String academicYear; // Store as String

        // Constructor
        public Module(int id, String name, String code, String academicYear) {
            this.id = id;
            this.name = name;
            this.code = code;
            this.academicYear = academicYear; // Store as String
        }

        // Getters
        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getCode() {
            return code;
        }

        public String getAcademicYear() {
            return academicYear; // Return as String
        }
    }



    private void loadComboBoxData() {
        loadAcademicYears(chooseAcademicYearML); // Load for Manage Lecturer
        loadAcademicYears(academicYearDropdown); // Load for Add Class
        loadAcademicYears(academicYearSemesterDropdown); // Load for Add Semester
        loadAcademicYears(chooseAcademicYearDropdown); // General dropdown
        loadClassesForModule(); // Load classes for Add Module
        loadClasses(chooseClassDropdown); // Load classes for Add Student
        loadClassesForAddStudent(); // Load classes specifically for Add Student
        loadSemesters(semesterDropdown); // Load semesters for Add Class
        loadSemesters(chooseSemesterDropdown); // Load semesters for Manage Lecturer
        loadSemesters(chooseSemesterDropdownML); // Load semesters for Manage Lecturer
        loadLecturers(); // Load lecturers for the Manage Lecturer pane
        loadModules(); // Load modules for the Manage Lecturer pane
    }
    private void loadSemesters(ComboBox<ComboBoxItem> chooseSemesterDropdown) {
        String query = "SELECT s.id, s.name, a.start_date, a.end_date " +
                "FROM Semester s " +
                "JOIN AcademicYear a ON s.academic_year_id = a.id"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            chooseSemesterDropdown.getItems().clear(); // Clear existing items for the dropdown
            while (resultSet.next()) {
                String semesterName = resultSet.getString("name");
                int startYear = resultSet.getDate("start_date").toLocalDate().getYear();
                int endYear = resultSet.getDate("end_date").toLocalDate().getYear();
                String formattedSemester = semesterName + " (" + startYear + "-" + endYear + ")"; // Format as "Semester 1 (2023-2024)"
                chooseSemesterDropdown.getItems().add(new ComboBoxItem(formattedSemester)); // Populate the dropdown
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public class Semester {
        private String name;
        private LocalDate startDate;
        private LocalDate endDate;
        private String academicYear;

        public Semester(String name, LocalDate startDate, LocalDate endDate, String academicYear) {
            this.name = name;
            this.startDate = startDate;
            this.endDate = endDate;
            this.academicYear = academicYear;
        }

        public String getName() {
            return name;
        }

        public LocalDate getStartDate() {
            return startDate;
        }

        public LocalDate getEndDate() {
            return endDate;
        }

        public String getAcademicYear() {
            return academicYear;
        }
    }

    private void loadSemestersIntoTable() {
        String query = "SELECT s.name AS semester_name, s.start_date, s.end_date, " +
                "CONCAT(YEAR(a.start_date), '-', YEAR(a.end_date)) AS academic_year " +
                "FROM Semester s " +
                "JOIN AcademicYear a ON s.academic_year_id = a.id"; // Join to get the formatted academic year
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Clear existing items in the table
            viewModulesTable1.getItems().clear();

            while (resultSet.next()) {
                String semesterName = resultSet.getString("semester_name");
                LocalDate startDate = resultSet.getDate("start_date").toLocalDate();
                LocalDate endDate = resultSet.getDate("end_date").toLocalDate();
                String academicYear = resultSet.getString("academic_year");

                // Create a new Semester object
                Semester semester = new Semester(semesterName, startDate, endDate, academicYear);
                viewModulesTable1.getItems().add(semester); // Add the semester to the table
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while loading semesters.");
        }
    }

    private void loadClasses(ComboBox<ComboBoxItem> chooseClassDropdown) {
        String query = "SELECT id, name FROM Class"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            chooseClassDropdownML.getItems().clear(); // Clear existing items for Manage Lecturer
            while (resultSet.next()) {
                String className = resultSet.getString("name");
                chooseClassDropdownML.getItems().add(new ComboBoxItem(className)); // Populate Manage Lecturer dropdown
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadClassesForAddStudent() {
        String query = "SELECT id, name FROM Class"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            assignStudentsClassDropdown.getItems().clear(); // Clear existing items for Add Student
            while (resultSet.next()) {
                String className = resultSet.getString("name");
                assignStudentsClassDropdown.getItems().add(new ComboBoxItem(className)); // Populate Add Student dropdown
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadClassesForModule() {
        String query = "SELECT id, name FROM Class"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            chooseClassDropdown.getItems().clear(); // Clear existing items for Add Module
            while (resultSet.next()) {
                String className = resultSet.getString("name");
                chooseClassDropdown.getItems().add(new ComboBoxItem(className)); // Populate Add Module dropdown
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadModulesIntoTable() {
        String query = "SELECT m.id AS module_id, m.name, m.code, CONCAT(YEAR(a.start_date), '-', YEAR(a.end_date)) AS academic_year " +
                "FROM Module m " +
                "JOIN AcademicYear a ON m.academic_year_id = a.id"; // Join to get the formatted academic year
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Clear existing items in the table
            viewModulesTable.getItems().clear();

            while (resultSet.next()) {
                int moduleId = resultSet.getInt("module_id"); // Use the alias for module ID
                String moduleName = resultSet.getString("name");
                String moduleCode = resultSet.getString("code");
                String academicYear = resultSet.getString("academic_year"); // Get the formatted academic year

                // Create a new Module object
                Module module = new Module(moduleId, moduleName, moduleCode, academicYear);
                viewModulesTable.getItems().add(module); // Add the module to the table
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while loading modules.");
        }
    }



    private void deleteModule(String moduleCode) {
        String query = "DELETE FROM Module WHERE code = ?"; // Assuming code is the unique identifier
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, moduleCode); // Use the module code to delete

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Module deleted successfully.");
                loadModulesIntoTable(); // Refresh the table
            } else {
                showAlert("Error", "Failed to delete module.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while deleting the module.");
        }
    }


    private void loadAcademicYears(ComboBox<ComboBoxItem> comboBox) {
        String query = "SELECT id, YEAR(start_date) AS start_year, YEAR(end_date) AS end_year FROM AcademicYear";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            comboBox.getItems().clear(); // Clear existing items
            while (resultSet.next()) {
                int startYear = resultSet.getInt("start_year");
                int endYear = resultSet.getInt("end_year");
                String academicYear = startYear + "-" + endYear; // Format as "startYear-endYear"
                comboBox.getItems().add(new ComboBoxItem(academicYear)); // Add ComboBoxItem
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadLecturers() {
        String query = "SELECT username, full_name FROM Lecturer"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            chooseLecturerDropdownML.getItems().clear(); // Clear existing items
            while (resultSet.next()) {
                String lecturerName = resultSet.getString("full_name");
                String lecturerID = resultSet.getString("username");
                chooseLecturerDropdownML.getItems().add(new ComboBoxItem(lecturerName + " (" + lecturerID + ")")); // Add ComboBoxItem
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadLecturersIntoTable() {
        String query = "SELECT username, full_name, role FROM Lecturer"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Clear existing items in the table
            viewLecturesTable.getItems().clear();

            while (resultSet.next()) {
                String lecturerID = resultSet.getString("username");
                String lecturerName = resultSet.getString("full_name");
                String lecturerRole = resultSet.getString("role");

                // Create a new Lecturer object
                Lecturer lecturer = new Lecturer(lecturerID, lecturerName, lecturerRole);
                viewLecturesTable.getItems().add(lecturer); // Add the lecturer to the table
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while loading lecturers.");
        }
    }

    private void deleteLecturer(Lecturer lecturer) {
        String query = "DELETE FROM Lecturer WHERE username = ?"; // Assuming username is the unique identifier
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, lecturer.getId()); // Use the lecturer ID (or username) to delete

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Lecturer deleted successfully.");
                loadLecturersIntoTable(); // Refresh the table
            } else {
                showAlert("Error", "Failed to delete lecturer.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while deleting the lecturer.");
        }
    }


    public class Lecturer {
        private String id;
        private String name;
        private String role;

        public Lecturer(String id, String name, String role) {
            this.id = id;
            this.name = name;
            this.role = role;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getRole() {
            return role;
        }
    }

    private void loadModules() {
        String query = "SELECT id, name FROM Module"; // Adjust the query as needed
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            ChooseModuleDropdownML.getItems().clear(); // Clear existing items
            while (resultSet.next()) {
                String moduleName = resultSet.getString("name");
                ChooseModuleDropdownML.getItems().add(new ComboBoxItem(moduleName)); // Add ComboBoxItem
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Helper class to hold ComboBox items
    public static class ComboBoxItem {
        private final String name;

        public ComboBoxItem(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name; // This will be displayed in the ComboBox
        }
    }

    public void loadAdminInfo() {
        String username = UserSession.getLoggedInUser (); // Get the logged-in user's username
        Connection connection = DatabaseConnection.getConnection(); // Get the singleton connection

        // Update the query to match your actual database schema
        String query = "SELECT full_name, username, faculty_department FROM FacultyAdmin WHERE username = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String fullName = resultSet.getString("full_name");
                String empId = resultSet.getString("username"); // Use 'username' as the employee ID
                String faculty = resultSet.getString("faculty_department");

                // Set the values in the respective fields
                admnNameField.setText(fullName);
                admnIDField.setText(empId); // This will now show the username
                admnFacultyField.setText(faculty);
            } else {
                System.out.println("No admin found with this username.");
                showAlert("Error", "No admin found with this username.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadSemesters(boolean loadForAddClass, boolean loadForManageLecturer) {
        String query = "SELECT id, name FROM Semester";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            if (loadForAddClass) {
                semesterDropdown.getItems().clear(); // Clear existing items for Add Class
            }
            if (loadForManageLecturer) {
                chooseSemesterDropdownML.getItems().clear(); // Clear existing items for Manage Lecturer
            }

            while (resultSet.next()) {
                String semesterName = resultSet.getString("name");

                if (loadForAddClass) {
                    semesterDropdown.getItems().add(new ComboBoxItem(semesterName)); // Populate Add Class dropdown
                }
                if (loadForManageLecturer) {
                    chooseSemesterDropdownML.getItems().add(new ComboBoxItem(semesterName)); // Populate Manage Lecturer dropdown
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void AddAcademicYearAndSemester(ActionEvent event) {
        showPane(anchorPaneAddYearSemester);
    }

    @FXML
    void AddAndManageLecturers(ActionEvent event) {
        showPane(anchorPaneAddLecture);
    }

    @FXML
    void AddAndManageStudents(ActionEvent event) {
        showPane(anchorPaneAddStudent);
    }

    @FXML
    void AddClass(ActionEvent event) {
        showPane(anchorPaneAddClass);
    }

    @FXML
    void AddModule(ActionEvent event) {
        showPane(anchorPaneAddModule);
    }

    @FXML
    void ClearLectureFields(ActionEvent event) {
        fieldLectureID.clear();
        fieldLectureName.clear();
        assignRoleDropdown.getSelectionModel().clearSelection();
    }
    @FXML
    void ClearModuleFields(ActionEvent event) {
        fieldModuleName.clear();
        fieldModuleCode.clear();
        chooseClassDropdown.setValue(null);
        chooseAcademicYearDropdown.setValue(null);
        chooseSemesterDropdown.setValue(null);
    }


    @FXML
    void ClearStudentsFields(ActionEvent event) {
        fieldStudentName.clear();
        fieldStudentID.clear();
        assignStudentsClassDropdown.setValue(null);
    }

    @FXML
    private void submitLectureBTN(ActionEvent event) {
        Connection connection = DatabaseConnection.getConnection();
        if (connection == null) {
            System.out.println("Database connection failed.");
            return;
        }

        String lecturerName = fieldLectureName.getText();
        String lecturerID = fieldLectureID.getText(); // This is used as the username
        String selectedRole = (String) assignRoleDropdown.getValue();

        if (selectedRole == null || selectedRole.isEmpty()) {
            System.out.println("Please select a role.");
            showAlert("Error", "Please select a role");
            return;
        }

        String checkLecturerSql = "SELECT COUNT(*) FROM Lecturer WHERE username = ?";
        try (PreparedStatement checkLecturerStatement = connection.prepareStatement(checkLecturerSql)) {
            checkLecturerStatement.setString(1, lecturerID);
            ResultSet rs = checkLecturerStatement.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                System.out.println("A lecturer with this ID already exists.");
                showAlert("Error", "A lecturer with this ID already exists.");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        }

        // Hash the lecturer's password (same as username) before saving
        String hashedPassword = BCrypt.hashpw(lecturerID, BCrypt.gensalt());

        String lecturerSql = "INSERT INTO Lecturer (username, password, full_name, role) VALUES (?, ?, ?, ?)";
        try (PreparedStatement lecturerStatement = connection.prepareStatement(lecturerSql)) {
            lecturerStatement.setString(1, lecturerID);
            lecturerStatement.setString(2, hashedPassword);  // Store the hashed password
            lecturerStatement.setString(3, lecturerName);
            lecturerStatement.setString(4, selectedRole);

            int lecturerRowsAffected = lecturerStatement.executeUpdate();
            if (lecturerRowsAffected > 0) {
                showAlert("Success", "Lecturer added successfully.");
            } else {
                showAlert("Error", "Failed to add Lecturer.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void GoToDashboard(ActionEvent event) {
        showPane(anchorPaneAdminDashboard);
    }

    @FXML
    void GoToHome(ActionEvent event) {
        showPane(anchorPaneAdminDashboard); // Adjust to your home pane
        refreshDashboard();
    }

    @FXML
    void HideAdminInfo(ActionEvent event) {
        adminDetailsAnchorPane.setVisible(false);
    }

    @FXML
    void Logout(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/Login.fxml"));
            Stage stage = (Stage) btnLogout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void ShowAdminInfo(ActionEvent event) {
        adminDetailsAnchorPane.setVisible(true);
    }

    @FXML
    void SubmitClassBTN(ActionEvent event) {
        // Get the class name and code from the input fields
        String className = fieldClassName.getText();
        String classCode = fieldClassCode.getText();

        // Get the selected academic year and semester from the ComboBoxes
        ComboBoxItem selectedAcademicYearItem = academicYearDropdown.getValue();
        ComboBoxItem selectedSemesterItem = semesterDropdown.getValue();

        // Validate input
        if (className.isEmpty() || classCode.isEmpty() || selectedAcademicYearItem == null || selectedSemesterItem == null) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        // Get academic year ID and semester ID
        int academicYearId = getAcademicYearId(selectedAcademicYearItem.toString());
        int semesterId = getSemesterId(selectedSemesterItem.toString());

        if (academicYearId == -1) {
            showAlert("Error", "Invalid academic year selected.");
            return;
        }

        if (semesterId == -1) {
            showAlert("Error", "Invalid semester selected.");
            return;
        }

        // SQL query to insert the class
        String insertQuery = "INSERT INTO Class (name, code, academic_year_id, semester_id) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setString(1, className);
            preparedStatement.setString(2, classCode);
            preparedStatement.setInt(3, academicYearId);
            preparedStatement.setInt(4, semesterId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Class added successfully.");
                ClearClassFields(event); // Clear fields after successful submission
            } else {
                showAlert("Error", "Failed to add class.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while adding the class.");
        }
    }

    // Method to get the semester ID based on the selected semester
    private int getSemesterId(String semester) {
        // Extract the semester name from the formatted string
        String semesterName = semester.split(" \\(")[0]; // Get the name before the " ("

        String query = "SELECT id FROM Semester WHERE name = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, semesterName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id"); // Return the ID of the semester
            } else {
                System.out.println("No semester found for: " + semesterName); // Debug statement
                showAlert("No Semester Found", "No semester found for: " + semesterName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if the semester ID is not found
    }

    @FXML
    void ClearClassFields(ActionEvent event) {
        fieldClassName.clear();
        fieldClassCode.clear();
        academicYearDropdown.setValue(null);
        semesterDropdown.setValue(null);
    }

    @FXML
    void SubmitModuleBTN(ActionEvent event) {
        String moduleName = fieldModuleName.getText();
        String moduleCode = fieldModuleCode.getText();

        ComboBoxItem selectedClassItem = chooseClassDropdown.getValue();
        ComboBoxItem selectedAcademicYearItem =  chooseAcademicYearDropdown.getValue();
        ComboBoxItem selectedSemesterItem =  chooseSemesterDropdown.getValue();

        // Validate input
        if (moduleName.isEmpty() || moduleCode.isEmpty() || selectedClassItem == null || selectedAcademicYearItem == null || selectedSemesterItem == null) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        // Get IDs for class, academic year, and semester
        int classId = getClassId(selectedClassItem.toString());
        int academicYearId = getAcademicYearId(selectedAcademicYearItem.toString());
        int semesterId = getSemesterId(selectedSemesterItem.toString());

        // SQL query to insert the module
        String insertQuery = "INSERT INTO Module (name, code, class_id, academic_year_id, semester_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement (insertQuery)) {
            preparedStatement.setString(1, moduleName);
            preparedStatement.setString(2, moduleCode);
            preparedStatement.setInt(3, classId);
            preparedStatement.setInt(4, academicYearId);
            preparedStatement.setInt(5, semesterId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Module added successfully.");
                ClearModuleFields(event); // Clear fields after successful submission
            } else {
                showAlert("Error", "Failed to add module.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while adding the module.");
        }
    }

    // Method to get class ID based on the selected class
    private int getClassId(String className) {
        String query = "SELECT id FROM Class WHERE name = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, className);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id"); // Return the ID of the class
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if class not found
    }

    @FXML
    void ViewLectures(ActionEvent event) {
        showPane(anchorPaneViewLecturers);
        loadLecturersIntoTable(); // Load lecturers into the table
    }

    @FXML
    void ViewModules(ActionEvent event) {
        showPane(anchorPaneViewModules);
        loadModulesIntoTable(); // Load modules into the table
    }

    @FXML
    void ViewSemesters(ActionEvent event) {
        showPane(anchorPaneViewSemesters);
        loadSemestersIntoTable();
    }

    @FXML
    void ManageLecturer(ActionEvent event) {
        showPane(anchorPaneManageLecturer);
    }

    @FXML
    void ClearAcademicYearFields(ActionEvent event) {
        fieldAcademicStartDate.setValue(null);
        fieldAcademicEndDate.setValue(null);
    }

    @FXML
    void submitAcademicYearBTN(ActionEvent event) {
        LocalDate startDate = fieldAcademicStartDate.getValue();
        LocalDate endDate = fieldAcademicEndDate.getValue();

        if (startDate == null || endDate == null) {
            System.out.println("Please select both start and end dates.");
            showAlert("No Semester Found", "Please select both start and end dates.");
            return;
        }

        if (startDate.isAfter(endDate)) {
            System.out.println("Start date must be before end date.");
            showAlert("No Semester Found", "Start date must be before end date.");
            return;
        }

        String insertQuery = "INSERT INTO AcademicYear (start_date, end_date) VALUES (?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setDate(1, java.sql.Date.valueOf(startDate));
            preparedStatement.setDate(2, java.sql.Date.valueOf(endDate));

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Academic year added successfully.");
                ClearAcademicYearFields(event); // Clear fields after successful submission
                loadAcademicYears(academicYearSemesterDropdown); // Load for Add Semester
            } else {
                showAlert("Faild", "Faild to add academic year.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to initialize and return a database connection
    private Connection initializeDatabaseConnection() {
        Connection connection = null;
        try {
            String url = "jdbc:mysql://localhost:3306/school";
            String user = "root";
            String password = "asus2005";

            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Database connection established successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to establish database connection.");
        }
        return connection;
    }

    @FXML
    void ClearSemesterFields(ActionEvent event) {
        fieldSemesterName.clear();
        fieldSemesterStartDate.setValue(null);
        fieldSemesterEndDate.setValue(null);
        academicYearSemesterDropdown.setValue(null);
    }

    @FXML
    void submitSemesterBTN(ActionEvent event) {
        // Get the semester name and dates from the input fields
        String semesterName = fieldSemesterName.getText();
        LocalDate startDate = fieldSemesterStartDate.getValue();
        LocalDate endDate = fieldSemesterEndDate.getValue();

        // Get the selected academic year from the ComboBox
        ComboBoxItem selectedItem = academicYearSemesterDropdown.getValue();
        if (selectedItem == null) {
            showAlert("Error", "Please select an academic year.");
            return;
        }

        // Extract the academic year ID and dates based on the selected year
        int academicYearId = getAcademicYearId(selectedItem.toString()); // Use the ComboBoxItem's toString
        LocalDate[] academicYearDates = getAcademicYearDates(academicYearId); // New method to get dates

        // Validate the input
        if (semesterName.isEmpty() || startDate == null || endDate == null || academicYearId == -1) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        // Check if the semester dates are within the academic year dates
        if (academicYearDates != null) {
            LocalDate academicYearStartDate = academicYearDates[0];
            LocalDate academicYearEndDate = academicYearDates[1];

            if (startDate.isBefore(academicYearStartDate) || endDate.isAfter(academicYearEndDate)) {
                showAlert("Error", "Semester dates must be within the selected academic year.");
                return;
            }
        }

        if (startDate.isAfter(endDate)) {
            showAlert("Error", "Start date must be before end date.");
            return;
        }

        // SQL query to insert the semester
        String insertQuery = "INSERT INTO Semester (name, start_date, end_date, academic_year_id) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setString(1, semesterName);
            preparedStatement.setDate(2, java.sql.Date.valueOf(startDate));
            preparedStatement.setDate(3, java.sql.Date.valueOf(endDate));
            preparedStatement.setInt(4, academicYearId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Semester added successfully.");
                ClearSemesterFields(event); // Clear fields after successful submission
            } else {
                showAlert("Error", "Failed to add semester.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while adding the semester.");
        }
    }

    // Method to show alert dialog
    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private LocalDate[] getAcademicYearDates(int academicYearId) {
        String query = "SELECT start_date, end_date FROM AcademicYear WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, academicYearId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                LocalDate startDate = resultSet.getDate("start_date").toLocalDate();
                LocalDate endDate = resultSet.getDate("end_date").toLocalDate();
                return new LocalDate[]{startDate, endDate}; // Return an array of dates
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if the academic year ID is not found
    }

    // Method to get the academic year ID based on the selected year
    private int getAcademicYearId(String academicYear) {
        String[] years = academicYear.split("-");
        int startYear = Integer.parseInt(years[0]);
        int endYear = Integer.parseInt(years[1]);

        String query = "SELECT id FROM AcademicYear WHERE YEAR(start_date) = ? AND YEAR(end_date) = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, startYear);
            preparedStatement.setInt(2, endYear);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id"); // Return the ID of the academic year
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if the academic year ID is not found
    }

    @FXML
    void submitStudentBTN(ActionEvent event) {
        String studentName = fieldStudentName.getText();
        String studentID = fieldStudentID.getText();
        ComboBoxItem selectedClassItem = (ComboBoxItem) assignStudentsClassDropdown.getValue();

        // Validate input
        if (studentName.isEmpty() || studentID.isEmpty() || selectedClassItem == null) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        int classId = getClassId(selectedClassItem.toString()); // Get class ID

        // SQL query to insert the student
        String insertQuery = "INSERT INTO Student (full_name, student_id, class_id) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setString(1, studentName);
            preparedStatement.setString(2, studentID);
            preparedStatement.setInt(3, classId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Student added successfully.");
                ClearStudentsFields(event); // Clear fields after successful submission
            } else {
                showAlert("Error", "Failed to add student.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while adding the student.");
        }
    }

    @FXML
    void AssignModule(ActionEvent event) {
        // Get selected values from ComboBoxes
        String selectedLecturer = chooseLecturerDropdownML.getValue() != null ? chooseLecturerDropdownML.getValue().toString() : null;
        String selectedModule = ChooseModuleDropdownML.getValue() != null ? ChooseModuleDropdownML.getValue().toString() : null;
        String selectedClass = chooseClassDropdownML.getValue() != null ? chooseClassDropdownML.getValue().toString() : null; // Get selected class

        if (selectedLecturer == null || selectedModule == null || selectedClass == null) {
            showAlert("Error", "Please select a lecturer, module, and class.");
            return;
        }

        // Extract lecturer code or username from the selected value
        String lecturerCode = selectedLecturer.split("\\(")[1].replace(")", "").trim();

        // Get the integer ID of the lecturer based on the lecturer code or username
        int lecturerID = getLecturerId(lecturerCode);

        if (lecturerID == -1) {
            showAlert("Error", "Invalid lecturer selected.");
            return;
        }

        // Get module ID from the Module table based on selected module name
        int moduleId = getModuleId(selectedModule);

        if (moduleId == -1) {
            showAlert("Error", "Invalid module selected.");
            return;
        }

        // Get class ID from the Class table based on selected class name
        int classId = getClassId(selectedClass);

        if (classId == -1) {
            showAlert("Error", "Invalid class selected.");
            return;
        }

        // SQL query to assign the module to the lecturer
        String insertQuery = "INSERT INTO LecturerModule (lecturer_id, module_id, class_id) VALUES (?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            preparedStatement.setInt(1, lecturerID); // Use the integer lecturer ID here
            preparedStatement.setInt(2, moduleId);
            preparedStatement.setInt(3, classId); // Include class ID

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Success", "Module assigned successfully.");
                ClearManageLectureFields(event);
            } else {
                showAlert("Error", "Failed to assign module.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while assigning the module.");
        }
    }

    private void refreshDashboard() {
        loadStudentCount(); // Refresh the student count
        loadLecturerCount(); // Refresh the lecturer count
        loadStudentCountsPerClass(); // Refresh student counts per class for the chart
    }

    // Method to get the lecturer ID from the database based on lecturer code or username
    private int getLecturerId(String lecturerCode) {
        String query = "SELECT id FROM Lecturer WHERE username = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, lecturerCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id");
            } else {
                return -1;  // Lecturer not found
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while retrieving the lecturer ID.");
            return -1;
        }
    }


    private int getModuleId(String moduleName) {
        String query = "SELECT id FROM Module WHERE name = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, moduleName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id"); // Return the ID of the module
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if module not found
    }

    @FXML
    void ClearManageLectureFields(ActionEvent event) {
        chooseLecturerDropdownML.getSelectionModel().clearSelection();
        ChooseModuleDropdownML.getSelectionModel().clearSelection();
        chooseClassDropdownML.getSelectionModel().clearSelection();
        chooseSemesterDropdownML.getSelectionModel().clearSelection();
        chooseAcademicYearML.getSelectionModel().clearSelection();
    }

    @FXML
    void GoToAddLecture(ActionEvent event) {
        showPane(anchorPaneAddLecture);
    }

    private void loadStudentCount() {
        String query = "SELECT COUNT(*) AS student_count FROM Student";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            if (resultSet.next()) {
                int studentCount = resultSet.getInt("student_count");
                lblNumOfStudentsEnrolled.setText(String.valueOf(studentCount)); // Update the label with the count
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while loading the student count.");
        }
    }

    private void loadLecturerCount() {
        String query = "SELECT COUNT(*) AS lecturer_count FROM Lecturer";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            if (resultSet.next()) {
                int lecturerCount = resultSet.getInt("lecturer_count");
                lblNumOfLectures.setText(String.valueOf(lecturerCount)); // Update the label with the count
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while loading the lecturer count.");
        }
    }

    private void loadStudentCountsPerClass() {
        String query = "SELECT c.name AS class_name, COUNT(s.id) AS student_count " +
                "FROM Class c LEFT JOIN Student s ON c.id = s.class_id " +
                "GROUP BY c.id"; // Group by class ID to count students

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            // Clear existing data in the chart
            studentsChart.getData().clear();

            // Create a series for the chart
            XYChart.Series<String, Number> series = new XYChart.Series<>();

            while (resultSet.next()) {
                String className = resultSet.getString("class_name");
                int studentCount = resultSet.getInt("student_count"); // Ensure this is an integer

                // Create data point and set its style
                XYChart.Data<String, Number> dataPoint = new XYChart.Data<>(className, studentCount);
                dataPoint.nodeProperty().addListener((obs, oldNode, newNode) -> {
                    if (newNode != null) {
                        newNode.setStyle("-fx-bar-fill: black;"); // Set the bar color to black
                    }
                });

                // Add data to the series
                series.getData().add(dataPoint);
            }

            // Add the series to the chart
            studentsChart.getData().add(series);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while loading student counts per class.");
        }
    }

    private void showPane(AnchorPane paneToShow) {
        // Hide all panes
        anchorPaneAddLecture.setVisible(false);
        anchorPaneAddStudent.setVisible(false);
        anchorPaneAddClass.setVisible(false);
        anchorPaneAddModule.setVisible(false);
        anchorPaneAddYearSemester.setVisible(false);
        anchorPaneViewLecturers.setVisible(false);
        anchorPaneViewModules.setVisible(false);
        anchorPaneViewSemesters.setVisible(false);
        anchorPaneAdminDashboard.setVisible(false);
        adminDetailsAnchorPane.setVisible(false);
        anchorPaneManageLecturer.setVisible(false);
        // Show the selected pane
        paneToShow.setVisible(true);

        // Reload ComboBox data if necessary
        if (paneToShow == anchorPaneManageLecturer) {
            loadComboBoxData(); // Load data for Manage Lecturer
        } else if (paneToShow == anchorPaneAddClass) {
            loadComboBoxData(); // Load data for Add Class
        } else if (paneToShow == anchorPaneAddModule) {
            loadComboBoxData(); // Load data for Add Module
        } else if (paneToShow == anchorPaneAddYearSemester) {
            loadComboBoxData(); // Load data for Add Semester
        }
    }
}