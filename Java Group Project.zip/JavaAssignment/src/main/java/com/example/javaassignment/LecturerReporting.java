package com.example.javaassignment;

import javafx.event.ActionEvent; import javafx.fxml.FXML; import javafx.fxml.FXMLLoader; import javafx.scene.Parent; import javafx.scene.Scene; import javafx.scene.control.*; import javafx.scene.layout.Pane; import javafx.scene.text.Text; import javafx.stage.Stage; import java.sql.Connection; import java.sql.PreparedStatement; import java.sql.ResultSet; import java.sql.SQLException;

public class LecturerReporting {
    public Button btnManageAttendance;
    @FXML
    private Pane LecturerInfoPane;

    @FXML
    private Button btnHideLecturerProfile;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnShowLecturerProfile;

    @FXML
    private Text lvlOfSatisfactionPlaceholder;

    @FXML
    private Button btnSubmitLecturerReporting;

    @FXML
    Text tblLectureReportTotNumInClass;

    @FXML
    Text tblLectureReportTotNumPresent;

    @FXML
    Text tblLectureReportTotNumAbsent;

    @FXML
    private Text lblLecturerName;

    @FXML
    private Pane lecturerDetailsPane;

    @FXML
    private Pane lecturerPaneWithShowProfileBtn;

    @FXML
    private TextField lecturerReportChallenges;

    @FXML
    private TextField lecturerReportChapter;

    @FXML
    private ComboBox<AdminProfile.ComboBoxItem> lecturerReportClass;


    @FXML
    private TextField lecturerReportDurationOfClass;

    @FXML
    private TextField lecturerReportLearningOutcome;

    @FXML
    private ComboBox<AdminProfile.ComboBoxItem> lecturerReportModuleCodeAndTitle;

    @FXML
    private ComboBox<String> lecturerReportName;

    @FXML
    private TextField lecturerReportRecommendations;

    @FXML
    private TextField lecturerReportWeek;

    @FXML
    private TextArea txtLecturerIDField;

    @FXML
    private TextArea txtLecturerNameField;

    @FXML
    private TextArea txtLecturerRole;

    @FXML
    public void initialize() {
        loadLecturerInfo();
        loadComboBoxData();

        // Set the admin's name in the lecturerReportName ComboBox and disable it
        String adminName = loadAdminName();
        if (adminName != null) {
            lecturerReportName.getItems().add(adminName);
            lecturerReportName.setValue(adminName); // Set the default displayed value
            lecturerReportName.setDisable(true); // Make ComboBox non-clickable
        }

        // Add listener to load classes based on selected module
        lecturerReportModuleCodeAndTitle.setOnAction(event -> {
            loadClassesForSelectedModule();
        });
    }

    public void loadLecturerInfo() {
        String username = UserSession.getLoggedInUser();
        Connection connection = DatabaseConnection.getConnection();

        String query = "SELECT full_name, username, role FROM Lecturer WHERE username = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String fullName = resultSet.getString("full_name");
                String empId = resultSet.getString("username");
                String role = resultSet.getString("role");

                txtLecturerNameField.setText(fullName);
                txtLecturerIDField.setText(empId);
                txtLecturerRole.setText(role);
            } else {
                System.out.println("No lecturer found with this username.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String loadAdminName() {
        String username = UserSession.getLoggedInUser();
        Connection connection = DatabaseConnection.getConnection();
        String fullName = null;

        String query = "SELECT full_name FROM Lecturer WHERE username = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                fullName = resultSet.getString("full_name");
            } else {
                System.out.println("No lecturer found with this username.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fullName; // Return the admin's full name
    }

    @FXML
    private Button btnManageAttendence;

    @FXML
    void GoToManageAttendence(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/LecturerStudentAttendance.fxml"));
            Stage stage = (Stage) btnManageAttendence.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void HideLecturerProfile(ActionEvent event) {
        lecturerDetailsPane.setVisible(false);
        btnShowLecturerProfile.setVisible(true);
    }

    @FXML
    void ShowLecturerProfile(ActionEvent event) {
        loadLecturerInfo();
        lecturerDetailsPane.setVisible(true);
        btnShowLecturerProfile.setVisible(false);
    }

    @FXML
    void Logout(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/Login.fxml"));
            Stage stage = (Stage) btnLogout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadComboBoxData() {
        loadAssignedModules(lecturerReportModuleCodeAndTitle);
        // No need to load all classes here; it will be done based on the selected module
        loadLecturers(lecturerReportName);
    }

    private void loadAssignedModules(ComboBox<AdminProfile.ComboBoxItem> comboBox) {
        String username = UserSession.getLoggedInUser ();
        String query = "SELECT m.id, m.name FROM Module m " +
                "JOIN LecturerModule lm ON m.id = lm.module_id " +
                "JOIN Lecturer l ON lm.lecturer_id = l.id " +
                "WHERE l.username = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            comboBox.getItems().clear(); // Clear previous items
            while (resultSet.next()) {
                String moduleName = resultSet.getString("name");
                comboBox.getItems().add(new AdminProfile.ComboBoxItem(moduleName)); // Add the module to the ComboBox
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private double attendancePercentage; // Class-level variable to store attendance percentage
    private void loadAttendanceData(String selectedClass, String date) {
        String query = "SELECT COUNT(*) AS total_students, " +
                "SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_count, " +
                "SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_count " +
                "FROM Attendance WHERE class_id = (SELECT id FROM Class WHERE name = ?) AND date = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, selectedClass);
            preparedStatement.setString(2, date);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int totalStudents = resultSet.getInt("total_students");
                int presentCount = resultSet.getInt("present_count");
                int absentCount = resultSet.getInt("absent_count");

                // Update the Text nodes with the results
                tblLectureReportTotNumInClass.setText(String.valueOf(totalStudents));
                tblLectureReportTotNumPresent.setText(String.valueOf(presentCount));
                tblLectureReportTotNumAbsent.setText(String.valueOf(absentCount));

                // Calculate attendance percentage
                attendancePercentage = totalStudents > 0 ? (double) presentCount / totalStudents * 100 : 0;

                // Update the satisfaction level text based on the attendance percentage
                updateSatisfactionLevel(attendancePercentage);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void updateSatisfactionLevel(double attendancePercentage) {
        String satisfactionText;
        String textColor;

        if (attendancePercentage >= 70) {
            satisfactionText = "Very Good";
            textColor = "green";
        } else if (attendancePercentage >= 50) {
            satisfactionText = "Good";
            textColor = "yellow"; // Adjust color as needed
        } else {
            satisfactionText = "Bad";
            textColor = "red";
        }

        // Update the text and color
        lvlOfSatisfactionPlaceholder.setText(satisfactionText);
        lvlOfSatisfactionPlaceholder.setFill(javafx.scene.paint.Color.web(textColor));
    }

    private void loadClassesForSelectedModule() {
        String selectedModule = lecturerReportModuleCodeAndTitle.getValue() != null ? lecturerReportModuleCodeAndTitle.getValue().toString() : null;

        if (selectedModule != null) {
            String query = "SELECT c.id, c.name FROM Class c " +
                    "JOIN Module m ON c.id = m.class_id " +
                    "WHERE m.name = ?";

            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, selectedModule);
                ResultSet resultSet = preparedStatement.executeQuery();

                lecturerReportClass.getItems().clear(); // Clear previous items
                while (resultSet.next()) {
                    String className = resultSet.getString("name");
                    lecturerReportClass.getItems().add(new AdminProfile.ComboBoxItem(className));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void loadModules(ComboBox comboBox) {
        String query = "SELECT id, name FROM Module";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            comboBox.getItems().clear();
            while (resultSet.next()) {
                String moduleName = resultSet.getString("name");
                comboBox.getItems().add(new AdminProfile.ComboBoxItem(moduleName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadLecturers(ComboBox comboBox) {
        String query = "SELECT username, full_name FROM Lecturer";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            comboBox.getItems().clear();
            while (resultSet.next()) {
                String lecturerName = resultSet.getString("full_name");
                comboBox.getItems().add(new AdminProfile.ComboBoxItem(lecturerName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void SubmitLecturerReporting(ActionEvent event) {
        if (lecturerReportClass.getValue() == null || lecturerReportModuleCodeAndTitle.getValue() == null || lecturerReportName.getValue() == null) {
            showAlert("Error", "Please fill in all required fields.");
            return;
        }

        // Get the attendance numbers from the text placeholders
        String totalInClass = tblLectureReportTotNumInClass.getText();
        String totalPresent = tblLectureReportTotNumPresent.getText();
        String totalAbsent = tblLectureReportTotNumAbsent.getText();

        if (totalPresent.isEmpty() || totalInClass.isEmpty()) {
            showAlert("Error", "Please ensure attendance is recorded before submitting the report.");
            return;
        }

        String selectedClass = lecturerReportClass.getValue().toString();
        String selectedModule = lecturerReportModuleCodeAndTitle.getValue().toString();
        String selectedLecturer = lecturerReportName.getValue().toString();
        String week = lecturerReportWeek.getText();
        String chapter = lecturerReportChapter.getText();
        String learningOutcome = lecturerReportLearningOutcome.getText();
        String challenges = lecturerReportChallenges.getText();
        String recommendations = lecturerReportRecommendations.getText();
        String duration = lecturerReportDurationOfClass.getText();

        // Reuse the same connection
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Get IDs before preparing the insert statement
            int lecturerId = getLecturerId(selectedLecturer, connection);
            int moduleId = getModuleId(selectedModule, connection);
            int classId = getClassId(selectedClass, connection);

            if (lecturerId == -1 || moduleId == -1 || classId == -1) {
                System.out.println("Invalid data. Cannot submit report.");
                return;
            }

            // Check if a report for the same week already exists
            if (reportExistsForWeek(lecturerId, moduleId, classId, week, connection)) {
                showAlert("Error", "A report for week " + week + " for this module and class already exists. Please submit a report for a different week.");
                return;
            }

            String insertQuery = "INSERT INTO LecturerReport (lecturer_id, module_id, class_id, week, chapter, learning_outcomes, challenges, recommendations, duration, total_present, total_absent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setInt(1, lecturerId);
                preparedStatement.setInt(2, moduleId);
                preparedStatement.setInt(3, classId);
                preparedStatement.setString(4, week);
                preparedStatement.setString(5, chapter);
                preparedStatement.setString(6, learningOutcome);
                preparedStatement.setString(7, challenges);
                preparedStatement.setString(8, recommendations);
                preparedStatement.setString(9, duration);
                preparedStatement.setInt(10, Integer.parseInt(totalPresent)); // Total present
                preparedStatement.setInt(11, Integer.parseInt(totalAbsent )); // Total absent

                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Report submitted successfully.");
                    showAlert("Success", "Report submitted successfully.");

                    // Reset the attendance numbers to 0
                    resetAttendanceNumbers();

                    // Update satisfaction level back to default
                    resetSatisfactionLevel(); // Ensure this is called after resetting attendance numbers

                    // Optionally, load attendance data after submitting the report
                    loadAttendanceData(selectedClass, java.time.LocalDate.now().toString());

                    // Update satisfaction level based on attendance percentage (if needed)
                    updateSatisfactionLevel(attendancePercentage);
                } else {
                    System.out.println("Failed to submit report.");
                    showAlert("Error", "Failed to submit report.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean reportExistsForWeek(int lecturerId, int moduleId, int classId, String week, Connection connection) {
        String query = "SELECT COUNT(*) FROM LecturerReport WHERE lecturer_id = ? AND module_id = ? AND class_id = ? AND week = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, lecturerId);
            preparedStatement.setInt(2, moduleId);
            preparedStatement.setInt(3, classId);
            preparedStatement.setString(4, week);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt(1) > 0; // Return true if a report exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // No report exists for the specified week
    }

    private void resetSatisfactionLevel() {
        // Reset the satisfaction level text back to "Auto Populate"
        lvlOfSatisfactionPlaceholder.setText("Auto Populate");
        lvlOfSatisfactionPlaceholder.setFill(javafx.scene.paint.Color.web("black")); // Reset color to default
    }

    private void resetAttendanceNumbers() {
        tblLectureReportTotNumInClass.setText("0");
        tblLectureReportTotNumPresent.setText("0");
        tblLectureReportTotNumAbsent.setText("0");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }



    public void updateAttendanceData(String selectedClass, String date) {
        loadAttendanceData(selectedClass, date);
    }

    private int getLecturerId(String lecturerName, Connection connection) {
        String query = "SELECT id FROM Lecturer WHERE full_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, lecturerName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getModuleId(String moduleName, Connection connection) {
        String query = "SELECT id FROM Module WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, moduleName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getClassId(String className, Connection connection) {
        String query = "SELECT id FROM Class WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, className);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @FXML
    private Button btnClearFieldsReportLecture;

    @FXML
    void ClearFieldsLecturerReporting(ActionEvent event) {
        // Reset all text fields
        lecturerReportChallenges.clear();
        lecturerReportChapter.clear();
        lecturerReportDurationOfClass.clear();
        lecturerReportLearningOutcome.clear();
        lecturerReportRecommendations.clear();
        lecturerReportWeek.clear();

        // Reset ComboBoxes
        lecturerReportClass.getSelectionModel().clearSelection();
        lecturerReportModuleCodeAndTitle.getSelectionModel().clearSelection();
    }
}