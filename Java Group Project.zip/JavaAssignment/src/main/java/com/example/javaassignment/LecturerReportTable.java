package com.example.javaassignment;

import javafx.collections.FXCollections; import javafx.collections.ObservableList; import javafx.event.ActionEvent; import javafx.fxml.FXML; import javafx.fxml.FXMLLoader; import javafx.scene.Parent; import javafx.scene.Scene; import javafx.scene.control.Alert; import javafx.scene.control.Button; import javafx.scene.control.TableColumn; import javafx.scene.control.TableView; import javafx.scene.control.cell.PropertyValueFactory; import javafx.stage.Stage;

import java.sql.Connection; import java.sql.PreparedStatement; import java.sql.ResultSet; import java.sql.SQLException;

public class LecturerReportTable {
    @FXML
    private TableView<LecturerReport> prlReportsTable;
    @FXML
    private Button btnGoToPrlReportAndProfile;

    @FXML
    private TableColumn<LecturerReport, String> LecturerReportsLecturer;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportsModule;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportsClass;
    @FXML
    private TableColumn<LecturerReport, Integer> LecturerReportWeek;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportChapterCovered;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportLearningOutcomes;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportChallenges;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportRecommendations;
    @FXML
    private TableColumn<LecturerReport, String> LecturerReportClassDuration;

    private ObservableList<LecturerReport> reports;

    @FXML
    public void initialize() {
        // Set up columns
        LecturerReportsLecturer.setCellValueFactory(new PropertyValueFactory<>("lecturer"));
        LecturerReportsModule.setCellValueFactory(new PropertyValueFactory<>("module"));
        LecturerReportsClass.setCellValueFactory(new PropertyValueFactory<>("className"));
        LecturerReportWeek.setCellValueFactory(new PropertyValueFactory<>("week"));
        LecturerReportChapterCovered.setCellValueFactory(new PropertyValueFactory<>("chapter"));
        LecturerReportLearningOutcomes.setCellValueFactory(new PropertyValueFactory<>("learningOutcomes"));
        LecturerReportChallenges.setCellValueFactory(new PropertyValueFactory<>("challenges"));
        LecturerReportRecommendations.setCellValueFactory(new PropertyValueFactory<>("recommendations"));
        LecturerReportClassDuration.setCellValueFactory(new PropertyValueFactory<>("duration"));

        // Load data into the table
        loadLecturerReports();
    }

    private void loadLecturerReports() {
        reports = FXCollections.observableArrayList();
        String query = "SELECT lr.id, l.full_name AS lecturer, m.name AS module, c.name AS class, lr.week, lr.chapter, lr.learning_outcomes, lr.challenges, lr.recommendations, lr.duration "
                + "FROM lecturerreport lr "
                + "JOIN lecturer l ON lr.lecturer_id = l.id "
                + "JOIN module m ON lr.module_id = m.id "
                + "JOIN class c ON lr.class_id = c.id";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String lecturer = resultSet.getString("lecturer");
                String module = resultSet.getString("module");
                String className = resultSet.getString("class");
                int week = resultSet.getInt("week");
                String chapter = resultSet.getString("chapter");
                String learningOutcomes = resultSet.getString("learning_outcomes");
                String challenges = resultSet.getString("challenges");
                String recommendations = resultSet.getString("recommendations");
                String duration = resultSet.getString("duration");

                reports.add(new LecturerReport(id, lecturer, module, className, week, chapter, learningOutcomes, challenges, recommendations, duration));
            }

            prlReportsTable.setItems(reports);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection or query issues
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    void GoToPrlReportAndProfile(ActionEvent actionEvent) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/PrlReportAndProfile.fxml"));
            Stage stage = (Stage) btnGoToPrlReportAndProfile.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            showAlert("Error", "Failed to load report and profile: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
}