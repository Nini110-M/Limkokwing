package com.example.javaassignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    static Connection connection;

    private DatabaseConnection() {
        // Private constructor to prevent instantiation
    }

    public static Connection getConnection() {
        if (connection == null || isConnectionClosed()) {
            try {
                String url = "jdbc:mysql://localhost:3306/Limko_system";
                String user = "root";
                String password = "asus2005";
                connection = DriverManager.getConnection(url, user, password);
                System.out.println("Database connection established successfully.");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Failed to establish database connection.");
            }
        }
        return connection;
    }

    private static boolean isConnectionClosed() {
        try {
            return connection == null || connection.isClosed();
        } catch (SQLException e) {
            e.printStackTrace();
            return true; // If we can't check, assume it's closed
        }
    }
}