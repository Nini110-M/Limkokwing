package com.example.javaassignment;

import javafx.collections.FXCollections; import javafx.collections.ObservableList; import javafx.event.ActionEvent; import javafx.fxml.FXML; import javafx.fxml.FXMLLoader; import javafx.scene.Parent; import javafx.scene.Scene; import javafx.scene.control.*; import javafx.scene.control.cell.CheckBoxTableCell; import javafx.scene.layout.Pane; import javafx.scene.text.Text; import javafx.stage.Stage;

import java.sql.Connection; import java.sql.PreparedStatement; import java.sql.ResultSet; import java.sql.SQLException;

public class LecturerStudentAttendance {
    @FXML
    public TextArea txtLecturerNameField;

    @FXML
    public TextArea txtLecturerIDField;

    @FXML
    private Pane LecturerInfoPane;

    @FXML
    private Button btnHideLecturerProfile;

    @FXML
    private Button btnHomeLecturerAttendance;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnShowLecturerProfile;

    @FXML
    private Label lblLecturerFaculty;

    @FXML
    private Label lblLecturerFullnames1;

    @FXML
    private Label lblLecturerID;

    @FXML
    private Text lblLecturerName;

    @FXML
    private Pane lecturerDetailsPane;

    @FXML
    private Pane lecturerPaneWithShowProfileBtn;

    @FXML
    private TableView<StudentAttendance> tbleattendance;

    @FXML
    private TableColumn<StudentAttendance, String> studentIdAttendance;

    @FXML
    private TableColumn<StudentAttendance, String> nameAttendance;

    @FXML
    private TableColumn<StudentAttendance, Boolean> presentAttendanceCheckbox;

    @FXML
    private TableColumn<StudentAttendance, Boolean> absentAttendanceCheckbox;

    @FXML
    private TextArea txtLecturerRole;

    @FXML
    private Text txtPRLProfile1;

    @FXML
    private Text txtlecProfile;

    @FXML
    private ComboBox<String> lecturerAttendanceClass;

    private ObservableList<StudentAttendance> attendanceList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Initialize the attendance table
        studentIdAttendance.setCellValueFactory(cellData -> cellData.getValue().studentIdProperty());
        nameAttendance.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

        // Make the table editable
        tbleattendance.setEditable(true);

        // Create checkboxes for present and absent
        presentAttendanceCheckbox.setCellValueFactory(cellData -> cellData.getValue().presentProperty());
        presentAttendanceCheckbox.setCellFactory(CheckBoxTableCell.forTableColumn(presentAttendanceCheckbox));

        absentAttendanceCheckbox.setCellValueFactory(cellData -> cellData.getValue().absentProperty());
        absentAttendanceCheckbox.setCellFactory(CheckBoxTableCell.forTableColumn(absentAttendanceCheckbox));

        // Optional: Add a listener to handle clicks on the checkboxes
        presentAttendanceCheckbox.setOnEditCommit(event -> {
            StudentAttendance attendance = event.getRowValue();
            attendance.presentProperty().set(event.getNewValue());
        });

        absentAttendanceCheckbox.setOnEditCommit(event -> {
            StudentAttendance attendance = event.getRowValue();
            attendance.absentProperty().set(event.getNewValue());
            // Optionally set present to false if absent is checked
            if (event.getNewValue()) {
                attendance.presentProperty().set(false);
            }
        });

        // Load classes into the ComboBox
        loadClasses();

        // Load students for the selected class
        lecturerAttendanceClass.setOnAction(event -> loadStudentsForAttendance());
    }

    private void loadClasses() {
        // Load classes from the database into the ComboBox
        Connection connection = DatabaseConnection.getConnection();
        String username = UserSession.getLoggedInUser (); // Get the logged-in user's username
        String query = "SELECT c.name FROM Class c " +
                "JOIN LecturerModule lm ON c.id = lm.class_id " +
                "JOIN Lecturer l ON lm.lecturer_id = l.id " +
                "WHERE l.username = ?"; // Filter by the logged-in lecturer

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                lecturerAttendanceClass.getItems().add(resultSet.getString("name")); // Add the class to the ComboBox
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadLecturerInfo() {
        String username = UserSession.getLoggedInUser (); // Get the logged-in user's username
        Connection connection = DatabaseConnection.getConnection(); // Get the singleton connection

        String query = "SELECT full_name, username, role FROM Lecturer WHERE username = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String fullName = resultSet.getString("full_name");
                String empId = resultSet.getString("username");
                String role = resultSet.getString("role");

                // Set the values in the respective fields
                txtLecturerNameField.setText(fullName);
                txtLecturerIDField.setText(empId);
                txtLecturerRole.setText(role);
            } else {
                System.out.println("No lecturer found with this username.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadStudentsForAttendance() {
        // Clear the current attendance list
        attendanceList.clear();

        // Load students from the database for the selected class
        String selectedClass = lecturerAttendanceClass.getSelectionModel().getSelectedItem();
        if (selectedClass == null) {
            return; // No class selected
        }

        Connection connection = DatabaseConnection.getConnection();
        String query = "SELECT student_id, full_name FROM Student WHERE class_id = (SELECT id FROM Class WHERE name = ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, selectedClass);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String studentId = resultSet.getString("student_id");
                String name = resultSet.getString("full_name");
                // Create StudentAttendance without passing absent status
                attendanceList.add(new StudentAttendance(studentId, name));
            }
            tbleattendance.setItems(attendanceList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void GoToLecturerReport(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/LecturerReporting.fxml"));
            Stage stage = (Stage) btnHomeLecturerAttendance.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void HideLecturerProfile(ActionEvent event) {
        lecturerDetailsPane.setVisible(false); // Hide the lecturer details pane
        lecturerDetailsPane.setVisible(false); // Hide the lecturer details pane
        btnShowLecturerProfile.setVisible(true); // Show the show profile button
    }

    @FXML
    void Logout(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/Login.fxml"));
            Stage stage = (Stage) btnLogout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void ShowLecturerProfile(ActionEvent event) {
        loadLecturerInfo(); // Load lecturer info when button is clicked
        lecturerDetailsPane.setVisible(true); // Make the pane visible
        btnShowLecturerProfile.setVisible(false); // Hide the show profile button
    }

    private int getClassId(String className) {
        int classId = -1; // Default value indicating not found
        Connection connection = DatabaseConnection.getConnection();
        String query = "SELECT id FROM Class WHERE name = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, className);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                classId = resultSet.getInt("id");
            } else {
                System.out.println("Class not found for name: " + className);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classId;
    }

    private int getModuleId() {
        int moduleId = -1; // Default value indicating not found
        // Assuming you have a way to determine the current lecturer and the module they are teaching.
        String username = UserSession.getLoggedInUser (); // Get the logged-in user's username
        Connection connection = DatabaseConnection.getConnection();

        String query = "SELECT module_id FROM LecturerModule WHERE lecturer_id = (SELECT id FROM Lecturer WHERE username = ?) LIMIT 1";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                moduleId = resultSet.getInt("module_id");
            } else {
                System.out.println("No module found for lecturer: " + username);
                showAlert("Error", "No module found for lecturer: " + username);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return moduleId;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    public void submitAttendance(ActionEvent actionEvent) {
        if (attendanceList.isEmpty()) {
            showAlert("Error", "Please enter attendance before submitting the report.");
            return;
        }

        int totalPresent = 0;
        int totalAbsent = 0;

        for (StudentAttendance attendance : attendanceList) {
            if (attendance.isPresent()) {
                totalPresent++;
            } else {
                totalAbsent++;
            }
        }

        // Update the text placeholders with the attendance numbers
        // You need to pass the attendance data to the reporting class here
        updateLecturerReporting(totalPresent, totalAbsent, attendanceList.size());

        // Show success alert
        showAlert("Success", "Attendance recorded successfully.");
    }

    private void updateLecturerReporting(int totalPresent, int totalAbsent, int totalStudents) {
        try {
            // Get the current stage and load the LecturerReporting controller
            Stage currentStage = (Stage) btnHomeLecturerAttendance.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/LecturerReporting.fxml"));
            Parent root = loader.load();
            LecturerReporting reportingController = loader.getController();

            // Update the text fields in the reporting controller
            reportingController.tblLectureReportTotNumInClass.setText(String.valueOf(totalStudents));
            reportingController.tblLectureReportTotNumPresent.setText(String.valueOf(totalPresent));
            reportingController.tblLectureReportTotNumAbsent.setText(String.valueOf(totalAbsent));

            // Calculate attendance percentage and update satisfaction level
            double attendancePercentage = totalStudents > 0 ? (double) totalPresent / totalStudents * 100 : 0;
            reportingController.updateSatisfactionLevel(attendancePercentage);

            // Optionally switch to the reporting scene
            currentStage.setScene(new Scene(root));
            currentStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}