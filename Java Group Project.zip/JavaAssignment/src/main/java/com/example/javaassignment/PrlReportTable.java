package com.example.javaassignment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrlReportTable {
    @FXML
    private TableView<PrlReport> prlReportsTable;
    @FXML
    private TableColumn<PrlReport, String> prlReportsLecturer, prlReportsClass, prlReportsCourseandModule,
            prlReportsChapterCoverdinaweek, prlReportsLecturerModeofdelivery,
            prlReportsRecommendations, prlReportsChallengesInaStream;
    @FXML
    private TableColumn<PrlReport, Integer> prlReportsstudentswhomissesMissedClasses, prlReportsAllegedInstancesofAssesssmentMalpractice;
    @FXML
    private Button btnGoToPrlReportAndProfile;

    @FXML
    public void initialize() {
        loadPrlReports();

        prlReportsLecturer.setCellValueFactory(cellData -> cellData.getValue().lecturerProperty());
        prlReportsClass.setCellValueFactory(cellData -> cellData.getValue().classNameProperty());
        prlReportsCourseandModule.setCellValueFactory(cellData -> cellData.getValue().courseAndModuleProperty());
        prlReportsChapterCoverdinaweek.setCellValueFactory(cellData -> cellData.getValue().chapterCoveredProperty());
        prlReportsLecturerModeofdelivery.setCellValueFactory(cellData -> cellData.getValue().modeOfDeliveryProperty());
        prlReportsstudentswhomissesMissedClasses.setCellValueFactory(cellData -> cellData.getValue().studentsWhoMissedClassesProperty().asObject());
        prlReportsRecommendations.setCellValueFactory(cellData -> cellData.getValue().recommendationsProperty());
        prlReportsChallengesInaStream.setCellValueFactory(cellData -> cellData.getValue().challengesProperty());
        prlReportsAllegedInstancesofAssesssmentMalpractice.setCellValueFactory(cellData -> cellData.getValue().allegedInstancesOfAssessmentMalpracticeProperty().asObject());
    }

    private void loadPrlReports() {
        ObservableList<PrlReport> reports = FXCollections.observableArrayList();
        String query = "SELECT l.full_name AS lecturer_name, c.name AS class_name, m.name AS module_name, " +
                "r.chapter, r.mode_of_delivery, r.students_who_missed_classes, " +
                "r.recommendations, r.challenges, r.alleged_instances_of_assessment_malpractice " +
                "FROM prlreport r " +
                "JOIN lecturer l ON r.lecturer_id = l.id " +
                "JOIN class c ON r.class_id = c.id " +
                "JOIN module m ON r.module_id = m.id";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                String lecturer = resultSet.getString("lecturer_name");
                String className = resultSet.getString("class_name");
                String courseAndModule = resultSet.getString("module_name");
                String chapterCovered = resultSet.getString("chapter");
                String modeOfDelivery = resultSet.getString("mode_of_delivery");
                int studentsWhoMissedClasses = resultSet.getInt("students_who_missed_classes");
                String recommendations = resultSet.getString("recommendations");
                String challenges = resultSet .getString("challenges");
                int allegedInstances = resultSet.getInt("alleged_instances_of_assessment_malpractice");

                reports.add(new PrlReport(lecturer, className, courseAndModule, chapterCovered, modeOfDelivery,
                        studentsWhoMissedClasses, recommendations, challenges, allegedInstances));
            }

            prlReportsTable.setItems(reports);
        } catch (SQLException e) {
            showAlert("Error", "Failed to load PRL reports: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void GoToPrlReportAndProfile(ActionEvent actionEvent) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/PrlReportAndProfile.fxml"));
            Stage stage = (Stage) btnGoToPrlReportAndProfile.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            showAlert("Error", "Failed to load report and profile: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}