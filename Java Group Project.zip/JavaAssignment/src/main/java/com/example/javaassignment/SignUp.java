package com.example.javaassignment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.mindrot.jbcrypt.BCrypt;

public class SignUp {

    @FXML
    private Button btnLogin;

    @FXML
    private TextField txtFullNamesField;

    @FXML
    private TextField txtFacultyNameField;

    @FXML
    private PasswordField txtPasswordField;

    @FXML
    public void AdminSignUP(ActionEvent event) {
        String fullName = txtFullNamesField.getText();
        String facultyName = txtFacultyNameField.getText();
        String password = txtPasswordField.getText();
        String username = password;  // Username is set to password

        if (fullName.isEmpty() || facultyName.isEmpty() || password.isEmpty()) {
            showAlert("Error", "All fields are required.");
            return;
        }

        // Hash the password using BCrypt
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        String query = "INSERT INTO facultyadmin (username, password, full_name, faculty_department) VALUES (?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, hashedPassword);  // Store the hashed password
            preparedStatement.setString(3, fullName);
            preparedStatement.setString(4, facultyName);

            int result = preparedStatement.executeUpdate();

            if (result > 0) {
                showAlert("Success", "Sign-up successful! Redirecting to login page.");
                GoToLogin(event);  // Navigate to login page after successful sign-up
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to sign up. Please try again.");
        }
    }

    @FXML
    void GoToLogin(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/Login.fxml"));
            Stage stage = (Stage) btnLogin.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login Page");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load the login page.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
