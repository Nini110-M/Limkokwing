package com.example.javaassignment;

import javafx.beans.property.*;

public class PrlReport {
    private final StringProperty lecturer;
    private final StringProperty className;
    private final StringProperty courseAndModule;
    private final StringProperty chapterCovered;
    private final StringProperty modeOfDelivery;
    private final IntegerProperty studentsWhoMissedClasses;
    private final StringProperty recommendations;
    private final StringProperty challenges;
    private final IntegerProperty allegedInstancesOfAssessmentMalpractice;

    public PrlReport(String lecturer, String className, String courseAndModule, String chapterCovered,
                     String modeOfDelivery, int studentsWhoMissedClasses, String recommendations,
                     String challenges, int allegedInstancesOfAssessmentMalpractice) {
        this.lecturer = new SimpleStringProperty(lecturer);
        this.className = new SimpleStringProperty(className);
        this.courseAndModule = new SimpleStringProperty(courseAndModule);
        this.chapterCovered = new SimpleStringProperty(chapterCovered);
        this.modeOfDelivery = new SimpleStringProperty(modeOfDelivery);
        this.studentsWhoMissedClasses = new SimpleIntegerProperty(studentsWhoMissedClasses);
        this.recommendations = new SimpleStringProperty(recommendations);
        this.challenges = new SimpleStringProperty(challenges);
        this.allegedInstancesOfAssessmentMalpractice = new SimpleIntegerProperty(allegedInstancesOfAssessmentMalpractice);
    }

    public StringProperty lecturerProperty() { return lecturer; }
    public StringProperty classNameProperty() { return className; }
    public StringProperty courseAndModuleProperty() { return courseAndModule; }
    public StringProperty chapterCoveredProperty() { return chapterCovered; }
    public StringProperty modeOfDeliveryProperty() { return modeOfDelivery; }
    public IntegerProperty studentsWhoMissedClassesProperty() { return studentsWhoMissedClasses; }
    public StringProperty recommendationsProperty() { return recommendations; }
    public StringProperty challengesProperty() { return challenges; }
    public IntegerProperty allegedInstancesOfAssessmentMalpracticeProperty() { return allegedInstancesOfAssessmentMalpractice; }
}