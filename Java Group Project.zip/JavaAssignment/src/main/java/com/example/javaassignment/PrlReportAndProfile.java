package com.example.javaassignment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrlReportAndProfile {

    public Pane PrlPaneWithShowProfileBtn;
    @FXML
    private Pane PrlDetailsPane;
    @FXML
    private Button ViewPrlReport, btnHidePRInfo, btnLogout, btnShowPrlInfo, btnSubmitPrlReport;
    @FXML
    private ComboBox<ClassItem> dropdownPRLreportclass;
    @FXML
    private ComboBox<LecturerItem> dropdownPRLreportlecture;
    @FXML
    private ComboBox<ModuleItem> dropdownPRLreportmodule;
    @FXML
    private Button ViewLecturerReportTable;
    @FXML
    private Label lblFullnames, lblPrlID, lblPrlRole;
    @FXML
    private TextArea txtPrlIDField, txtPrlNameField, txtRoleField;
    @FXML
    private TextField txtPRLreportAllegedinstancesofassessmentmalpractice,
            txtPRLreportRecommendations,
            txtPRLreportchallengesinastream,
            txtPRLreportchapterCoveredinaWeek,
            txtPRLreportmodeofDelivery,
            txtPRLreportstudentregistrationPercourse,
            txtPRLreportstudentwhomissedclasses;

    @FXML
    public void initialize() {
        loadPrlInfo();
        loadClasses();
        loadModules();
        loadLecturers();
        PrlDetailsPane.setVisible(true);
    }

    @FXML
    void GoToViewPrlReport(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/PrlReportTable.fxml"));
            Stage stage = (Stage) ViewPrlReport.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            showAlert("Error", "Failed to load report table: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void GoToViewLecturerReport(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/LecturerReportTable.fxml"));
            Stage stage = (Stage) ViewLecturerReportTable.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            showAlert("Error", "Failed to load lecturer report table: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void HidePrlInfo(ActionEvent event) {
        PrlDetailsPane.setVisible(false);
        btnShowPrlInfo.setVisible(true);
    }

    @FXML
    void Logout(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/Login.fxml"));
            Stage stage = (Stage) btnLogout.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            showAlert("Error", "Failed to log out: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void onShowPrlInfo(ActionEvent event) {
        loadPrlInfo();
        PrlDetailsPane.setVisible(true);
        btnShowPrlInfo.setVisible(false);
    }

    public class ClassItem {
        private final int id;
        private final String name;

        public ClassItem(int id, String name) {
            this.id = id;
            this.name = name;
        }

        public int getId() { return id; }
        public String getName() { return name; }

        @Override
        public String toString() { return name; }
    }

    public class LecturerItem {
        private final String id;
        private final String fullName;

        public LecturerItem(String id, String fullName) {
            this.id = id;
            this.fullName = fullName;
        }

        public String getId() { return id; }
        public String getFullName() { return fullName; }

        @Override
        public String toString() { return fullName; }
    }

    public class ModuleItem {
        private final int id;
        private final String name;

        public ModuleItem(int id, String name) {
            this.id = id;
            this.name = name;
        }

        public int getId() { return id; }
        public String getName() { return name; }

        @Override
        public String toString() { return name; }
    }

    public void loadPrlInfo() {
        String username = UserSession.getLoggedInUser ();
        Connection connection = DatabaseConnection.getConnection();

        String query = "SELECT full_name, username, role FROM Lecturer WHERE username = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String fullName = resultSet.getString("full_name");
                String empId = resultSet.getString("username");
                String role = resultSet.getString("role");

                txtPrlNameField.setText(fullName);
                txtPrlIDField.setText(empId);
                txtRoleField.setText(role);
            } else {
                showAlert("Info", "No PRL found with this username.", Alert.AlertType.INFORMATION);
            }
        } catch (SQLException e) {
            showAlert("Error", "Database error: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void loadClasses() {
        ObservableList<ClassItem> classes = FXCollections.observableArrayList();
        String query = "SELECT id, name FROM class";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                classes.add(new ClassItem(id, name));
            }
            dropdownPRLreportclass.setItems(classes);
        } catch (SQLException e) {
            showAlert("Error", "Failed to load classes: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void loadModules() {
        ObservableList<ModuleItem> modules = FXCollections.observableArrayList();
        String query = "SELECT id, name FROM module";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                modules.add(new ModuleItem(id, name));
            }
            dropdownPRLreportmodule.setItems(modules);
        } catch (SQLException e) {
            showAlert("Error", "Failed to load modules: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void loadLecturers() {
        ObservableList<LecturerItem> lecturers = FXCollections.observableArrayList();
        String query = "SELECT id, full_name FROM lecturer";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                String id = resultSet.getString("id");
                String fullName = resultSet.getString("full_name");
                lecturers.add(new LecturerItem(id, fullName));
            }
            dropdownPRLreportlecture.setItems(lecturers);
        } catch (SQLException e) {
            showAlert("Error", "Failed to load lecturers: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void submitPrlReport(ActionEvent event) {
        String chapter = txtPRLreportchapterCoveredinaWeek.getText();
        String modeOfDelivery = txtPRLreportmodeofDelivery.getText();
        String studentsWhoMissedClassesStr = txtPRLreportstudentwhomissedclasses.getText();
        String studentRegistrationPerCourseStr = txtPRLreportstudentregistrationPercourse.getText();
        String challenges = txtPRLreportchallengesinastream.getText();
        String recommendations = txtPRLreportRecommendations.getText();
        String allegedInstancesStr = txtPRLreportAllegedinstancesofassessmentmalpractice.getText();

        if (studentsWhoMissedClassesStr.isEmpty() || studentRegistrationPerCourseStr.isEmpty() || allegedInstancesStr.isEmpty()) {
            showAlert("Input Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return;
        }

        try {
            int studentsWhoMissedClasses = Integer.parseInt(studentsWhoMissedClassesStr);
            int studentRegistrationPerCourse = Integer.parseInt(studentRegistrationPerCourseStr);
            int allegedInstances = Integer.parseInt(allegedInstancesStr);

            // Proceed with database insertion
            LecturerItem selectedLecturer = dropdownPRLreportlecture.getValue();
            ModuleItem selectedModule = dropdownPRLreportmodule.getValue();
            ClassItem selectedClass = dropdownPRLreportclass.getValue();

            if (selectedLecturer == null || selectedModule == null || selectedClass == null) {
                showAlert("Selection Error", "Please select a lecturer, module, and class.", Alert.AlertType.ERROR);
                return;
            }

            String query = "INSERT INTO PRLReport (lecturer_id, module_id, class_id , week, chapter, mode_of_delivery, students_who_missed_classes, student_registration_per_course, challenges, recommendations, alleged_instances_of_assessment_malpractice) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, selectedLecturer.getId());
                preparedStatement.setInt(2, selectedModule.getId());
                preparedStatement.setInt(3, selectedClass.getId());
                preparedStatement.setInt(4, 1); // Assuming a default week
                preparedStatement.setString(5, chapter);
                preparedStatement.setString(6, modeOfDelivery);
                preparedStatement.setInt(7, studentsWhoMissedClasses);
                preparedStatement.setInt(8, studentRegistrationPerCourse);
                preparedStatement.setString(9, challenges);
                preparedStatement.setString(10, recommendations);
                preparedStatement.setInt(11, allegedInstances);

                preparedStatement.executeUpdate();
                showAlert("Success", "PRL Report submitted successfully.", Alert.AlertType.INFORMATION);
            } catch (SQLException e) {
                showAlert("Submission Error", "Error submitting PRL Report: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Please enter valid numbers for the fields.", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}