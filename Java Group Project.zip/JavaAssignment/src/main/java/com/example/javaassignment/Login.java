package com.example.javaassignment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.mindrot.jbcrypt.BCrypt;

public class Login {

    @FXML
    private TextField txtUsername;
    @FXML
    private TextField txtPassword;
    @FXML
    private Button btnLogin;
    @FXML
    private Button btnSignUP;

    @FXML
    private void Login(ActionEvent event) {
        String username = txtUsername.getText();
        String password = txtPassword.getText();

        // Validate login against the database
        String userRole = authenticateUser (username, password);
        if (userRole != null) {
            UserSession.setLoggedInUser (username); // Set the logged-in user

            // Log the login time and username
            logLogin(username);

            // Show success alert
            showAlert("Login Successful", "Welcome " + userRole + " " + username + "!");

            // Load the appropriate FXML based on user role
            try {
                FXMLLoader fxmlLoader;
                if (userRole.equals("admin")) {
                    fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/AdminProfile.fxml"));
                } else if (userRole.equals("principal_lecturer")) {
                    fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/PrlReportAndProfile.fxml"));
                } else if (userRole.equals("normal_lecturer")) {
                    fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/LecturerReporting.fxml"));
                } else {
                    throw new IllegalStateException("Unexpected value: " + userRole);
                }

                Stage stage = (Stage) btnLogin.getScene().getWindow();
                stage.setScene(new Scene(fxmlLoader.load()));
                stage.setTitle("Profile");
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Error", "Failed to load the profile page.");
            }
        } else {
            // Show an alert if login fails
            showAlert("Login Failed", "Invalid username or password. Please try again.");
        }
    }

    private String authenticateUser(String username, String password) {
        String query = "SELECT 'admin' AS user_type, password FROM FacultyAdmin WHERE LOWER(username) = LOWER(?) " +
                "UNION ALL " +
                "SELECT role, password FROM Lecturer WHERE LOWER(username) = LOWER(?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            // Use LOWER to handle case sensitivity in the database query
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String storedPasswordHash = resultSet.getString("password");

                // Try-catch to handle potential BCrypt errors
                try {
                    if (BCrypt.checkpw(password, storedPasswordHash)) {
                        return resultSet.getString("user_type");  // Return the user role if password matches
                    }
                } catch (IllegalArgumentException e) {
                    showAlert("Login Error", "An error occurred during login. Please check your credentials.");
                    return null;  // Exit the function if there's an issue with BCrypt
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to connect to the database. Please try again later.");
        }

        return null;  // Return null if authentication fails
    }


    private void logLogin(String username) {
        // Format the current date and time
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        // Prepare the log message
        String logMessage = "Login - User: " + username + " | Time: " + timestamp + "\n";

        // Write the log message to the log file
        try (FileWriter writer = new FileWriter("login_log.txt", true)) { // Append mode
            writer.write(logMessage);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to write to the log file.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION); // Change to INFORMATION for success messages
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void GoToSignUp(ActionEvent actionEvent) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/SignUp.fxml"));
            Stage stage = (Stage) btnSignUP.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Sign Up");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load the sign-up page.");
        }
    }
}