package com.example.javaassignment;

import javafx.beans.property.*;

public class LecturerReport {
    private final IntegerProperty id;
    private final StringProperty lecturer;
    private final StringProperty module;
    private final StringProperty className;
    private final IntegerProperty week;
    private final StringProperty chapter;
    private final StringProperty learningOutcomes;
    private final StringProperty challenges;
    private final StringProperty recommendations;
    private final StringProperty duration;

    public LecturerReport(int id, String lecturer, String module, String className, int week, String chapter, String learningOutcomes, String challenges, String recommendations, String duration) {
        this.id = new SimpleIntegerProperty(id);
        this.lecturer = new SimpleStringProperty(lecturer);
        this.module = new SimpleStringProperty(module);
        this.className = new SimpleStringProperty(className);
        this.week = new SimpleIntegerProperty(week);
        this.chapter = new SimpleStringProperty(chapter);
        this.learningOutcomes = new SimpleStringProperty(learningOutcomes);
        this.challenges = new SimpleStringProperty(challenges);
        this.recommendations = new SimpleStringProperty(recommendations);
        this.duration = new SimpleStringProperty(duration);
    }

    public int getId() { return id.get(); }
    public String getLecturer() { return lecturer.get(); }
    public String getModule() { return module.get(); }
    public String getClassName() { return className.get(); }
    public int getWeek() { return week.get(); }
    public String getChapter() { return chapter.get(); }
    public String getLearningOutcomes() { return learningOutcomes.get(); }
    public String getChallenges() { return challenges.get(); }
    public String getRecommendations() { return recommendations.get(); }
    public String getDuration() { return duration.get(); }

    // Add property methods for binding with TableColumns
    public IntegerProperty idProperty() { return id; }
    public StringProperty lecturerProperty() { return lecturer; }
    public StringProperty moduleProperty() { return module; }
    public StringProperty classNameProperty() { return className; }
    public IntegerProperty weekProperty() { return week; }
    public StringProperty chapterProperty() { return chapter; }
    public StringProperty learningOutcomesProperty() { return learningOutcomes; }
    public StringProperty challengesProperty() { return challenges; }
    public StringProperty recommendationsProperty() { return recommendations; }
    public StringProperty durationProperty() { return duration; }
}
