package com.example.javaassignment;

public class Module {
    private String lecturer;
    private String className;
    private String moduleName;
    private String chapterCovered;
    private String modeOfDelivery;
    private String missedClasses;
    private String studentAttendance;
    private String registrationsPerClass;
    private String challenges;
    private String recommendations;
    private String malpracticeInstances;

    public Module(String lecturer, String className, String moduleName, String chapterCovered,
                  String modeOfDelivery, String missedClasses, String studentAttendance,
                  String registrationsPerClass, String challenges, String recommendations,
                  String malpracticeInstances) {
        this.lecturer = lecturer;
        this.className = className;
        this.moduleName = moduleName;
        this.chapterCovered = chapterCovered;
        this.modeOfDelivery = modeOfDelivery;
        this.missedClasses = missedClasses;
        this.studentAttendance = studentAttendance;
        this.registrationsPerClass = registrationsPerClass;
        this.challenges = challenges;
        this.recommendations = recommendations;
        this.malpracticeInstances = malpracticeInstances;
    }

    public String getLecturer() { return lecturer; }
}