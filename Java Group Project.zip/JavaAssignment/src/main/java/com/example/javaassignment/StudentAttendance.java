package com.example.javaassignment;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class StudentAttendance {
    private final StringProperty studentId;
    private final StringProperty name;
    private final BooleanProperty present;
    private final BooleanProperty absent;

    public StudentAttendance(String studentId, String name) {
        this.studentId = new SimpleStringProperty(studentId);
        this.name = new SimpleStringProperty(name);
        this.present = new SimpleBooleanProperty(false);
        this.absent = new SimpleBooleanProperty(false);
    }

    public String getStudentId() {
        return studentId.get();
    }

    public StringProperty studentIdProperty() {
        return studentId;
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public boolean isPresent() {
        return present.get();
    }

    public BooleanProperty presentProperty() {
        return present;
    }

    public boolean isAbsent() {
        return absent.get();
    }

    public BooleanProperty absentProperty() {
        return absent;
    }
}